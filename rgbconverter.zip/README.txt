Readme

Usage: 'rgbconverter.exe valuein bits mode'

valuein =               decimal number or rgb value
bits    =               16 by default
mode    =               0:from/to RGB 1: to binary2 2: from binary2

example: 'rgbconverter.exe 542 16', 'rgbconverter.exe XXXXXXRXXXXRRRRXX'

for gui just run: 'rgbconverter' or 'rgbconverter 0 0 3